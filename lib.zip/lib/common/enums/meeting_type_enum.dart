enum MeetingTypes{
  inPerson,
  online
}