enum MeetingTypes{
  inPerson,
  online
}