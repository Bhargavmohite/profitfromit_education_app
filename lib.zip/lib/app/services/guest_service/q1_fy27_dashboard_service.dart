import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:webinar/common/utils/constants.dart';

class Q1FY27DashboardService {
  const Q1FY27DashboardService._();

  static const Duration _timeout = Duration(seconds: 45);

  /// Fetches Q1 FY27 HTML from the Laravel endpoint.
  ///
  /// Supports BOTH server response formats:
  ///
  /// 1) Raw HTML:
  ///    <!DOCTYPE html>...
  ///
  /// 2) JSON wrapped HTML:
  ///    {
  ///      "status": "success",
  ///      "html": "<!DOCTYPE html>..."
  ///    }
  ///
  /// This makes the Flutter app tolerant to the current server behaviour.
  static Future<String> fetchHtml() async {
    const String url = '${Constants.dommain}/q1-fy27-html-api';

    try {
      debugPrint('Q1 FY27 HTML API URL ======> $url');

      final http.Response response = await http.get(
        Uri.parse(url),
        headers: const <String, String>{
          'Accept': 'text/html,application/json',
          'Cache-Control': 'no-cache',
        },
      ).timeout(_timeout);

      debugPrint(
        'Q1 FY27 HTML API STATUS ======> ${response.statusCode}',
      );

      final String rawBody = utf8.decode(
        response.bodyBytes,
        allowMalformed: true,
      );

      debugPrint(
        'Q1 FY27 HTML API BODY LENGTH ======> ${rawBody.length}',
      );

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception(
          'Q1 FY27 endpoint returned HTTP ${response.statusCode}.',
        );
      }

      if (rawBody.trim().isEmpty) {
        throw const FormatException(
          'Q1 FY27 endpoint returned an empty response.',
        );
      }

      final String trimmed = rawBody.trimLeft();
      final String lower = trimmed.toLowerCase();

      // CURRENT SERVER BEHAVIOUR:
      // If Laravel sends the rendered Blade directly as HTML,
      // do NOT jsonDecode it. Return it straight to the WebView.
      if (lower.startsWith('<!doctype html') || lower.startsWith('<html')) {
        debugPrint(
          'Q1 FY27 RAW HTML SUCCESS ======> ${rawBody.length} characters',
        );
        return rawBody;
      }

      // FUTURE / OPTIONAL SERVER BEHAVIOUR:
      // If Laravel sends {"status":"success","html":"..."},
      // decode the JSON and extract the HTML.
      final dynamic decoded = jsonDecode(rawBody);

      if (decoded is String && decoded.trim().isNotEmpty) {
        debugPrint(
          'Q1 FY27 STRING HTML SUCCESS ======> ${decoded.length} characters',
        );
        return decoded;
      }

      if (decoded is! Map) {
        throw const FormatException(
          'Q1 FY27 response is neither HTML nor a valid JSON object.',
        );
      }

      final Map<String, dynamic> root = Map<String, dynamic>.from(decoded);

      final String status = root['status']?.toString().toLowerCase() ?? '';

      if (status.isNotEmpty && status != 'success') {
        throw Exception(
          root['message']?.toString() ??
              'Q1 FY27 endpoint returned an unsuccessful response.',
        );
      }

      final String html = root['html']?.toString() ?? '';

      if (html.trim().isEmpty) {
        throw const FormatException(
          'Q1 FY27 JSON response does not contain HTML.',
        );
      }

      debugPrint(
        'Q1 FY27 JSON HTML SUCCESS ======> ${html.length} characters',
      );

      return html;
    } catch (e, stack) {
      debugPrint('Q1 FY27 HTML API ERROR ======> $e');
      debugPrintStack(
        label: 'Q1 FY27 HTML API STACK',
        stackTrace: stack,
      );
      rethrow;
    }
  }
}
