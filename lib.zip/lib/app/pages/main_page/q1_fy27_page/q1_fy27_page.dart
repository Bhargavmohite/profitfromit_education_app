import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:webinar/app/services/guest_service/q1_fy27_dashboard_service.dart';
import 'package:webinar/common/utils/constants.dart';
import 'package:webinar/config/colors.dart';

class Q1FY27Page extends StatefulWidget {
  const Q1FY27Page({super.key});

  static const String pageName = '/q1-fy27';

  @override
  State<Q1FY27Page> createState() => _Q1FY27PageState();
}

class _Q1FY27PageState extends State<Q1FY27Page> {
  late Future<String> _htmlFuture;
  double _progress = 0;

  final InAppWebViewSettings _settings = InAppWebViewSettings(
    isInspectable: kDebugMode,
    javaScriptEnabled: true,
    javaScriptCanOpenWindowsAutomatically: true,
    mediaPlaybackRequiresUserGesture: false,
    allowsInlineMediaPlayback: true,
    iframeAllowFullscreen: true,
    useHybridComposition: true,
    transparentBackground: false,
  );

  @override
  void initState() {
    super.initState();
    _htmlFuture = Q1FY27DashboardService.fetchHtml();
  }

  void _retry() {
    setState(() {
      _progress = 0;
      _htmlFuture = Q1FY27DashboardService.fetchHtml();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: green77(),
        foregroundColor: Colors.white,
        centerTitle: true,
        title: const Text(
          'Q1FY27',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      body: FutureBuilder<String>(
        future: _htmlFuture,
        builder: (
          BuildContext context,
          AsyncSnapshot<String> snapshot,
        ) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          if (snapshot.hasError || !snapshot.hasData) {
            return _Q1HtmlErrorState(
              message: snapshot.error?.toString() ??
                  'Unable to load Q1 FY27 dashboard.',
              onRetry: _retry,
            );
          }

          final String html = snapshot.data!;

          return Stack(
            children: <Widget>[
              InAppWebView(
                initialData: InAppWebViewInitialData(
                  data: html,
                  mimeType: 'text/html',
                  encoding: 'utf-8',
                  baseUrl: WebUri('${Constants.dommain}/'),
                ),
                initialSettings: _settings,
                onProgressChanged: (
                  InAppWebViewController controller,
                  int progress,
                ) {
                  if (!mounted) return;

                  setState(() {
                    _progress = progress / 100;
                  });
                },
                onLoadStop: (
                  InAppWebViewController controller,
                  WebUri? url,
                ) {
                  if (!mounted) return;

                  setState(() {
                    _progress = 1;
                  });
                },
                onReceivedError: (
                  InAppWebViewController controller,
                  WebResourceRequest request,
                  WebResourceError error,
                ) {
                  debugPrint(
                    'Q1 FY27 WEBVIEW ERROR ======> '
                    '${error.description}',
                  );
                },
                onConsoleMessage: (
                  InAppWebViewController controller,
                  ConsoleMessage consoleMessage,
                ) {
                  debugPrint(
                    'Q1 FY27 WEBVIEW CONSOLE ======> '
                    '${consoleMessage.message}',
                  );
                },
              ),
              if (_progress < 1)
                LinearProgressIndicator(
                  value: _progress > 0 ? _progress : null,
                  minHeight: 2,
                ),
            ],
          );
        },
      ),
    );
  }
}

class _Q1HtmlErrorState extends StatelessWidget {
  const _Q1HtmlErrorState({
    required this.message,
    required this.onRetry,
  });

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Container(
          width: double.infinity,
          constraints: const BoxConstraints(maxWidth: 520),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: const Color(0xFFE4E7EC),
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              const Icon(
                Icons.cloud_off_rounded,
                size: 54,
                color: Color(0xFFE5484D),
              ),
              const SizedBox(height: 18),
              const Text(
                'Unable to load Q1 FY27 data',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF101828),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 14,
                  height: 1.5,
                  color: Color(0xFF667085),
                ),
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Retry'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
