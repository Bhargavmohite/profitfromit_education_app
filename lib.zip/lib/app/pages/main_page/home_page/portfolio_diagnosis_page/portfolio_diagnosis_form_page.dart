import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webinar/app/widgets/native_service_forms/native_service_form_widgets.dart';

/// A plan selected in the existing Portfolio Diagnosis cards.
/// Price is deliberately not calculated in Flutter; Laravel will quote it.
enum DiagnosisPlan { individual, family }

extension DiagnosisPlanInfo on DiagnosisPlan {
  String get id => this == DiagnosisPlan.individual
      ? 'individual_audit' : 'family_wealth_audit';
  String get title => this == DiagnosisPlan.individual
      ? 'Individual Audit' : 'Family Wealth Audit';
  String get description => this == DiagnosisPlan.individual
      ? 'Review one portfolio' : 'Review household portfolios';
}

class PortfolioDiagnosisFormPage extends StatefulWidget {
  const PortfolioDiagnosisFormPage({super.key, required this.plan});

  final DiagnosisPlan plan;

  @override
  State<PortfolioDiagnosisFormPage> createState() => _PortfolioDiagnosisFormPageState();
}

class _PortfolioDiagnosisFormPageState extends State<PortfolioDiagnosisFormPage> {
  static const _steps = ['About you', 'Your investments', 'Documents', 'Review'];

  final _formKeys = List.generate(3, (_) => GlobalKey<FormState>());
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _mobile = TextEditingController();
  final _age = TextEditingController();
  final _city = TextEditingController();
  final _accounts = TextEditingController(text: '1');
  final _value = TextEditingController();
  final _broker = TextEditingController();
  final _goals = TextEditingController();
  String? _experience;
  String? _relationship;
  bool _isStudent = false;
  bool _consent = false;
  bool _pickingFiles = false;
  int _step = 0;
  final List<PlatformFile> _documents = [];

  @override
  void dispose() {
    for (final c in [_name, _email, _mobile, _age, _city, _accounts,
      _value, _broker, _goals]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pickDocuments() async {
    if (_pickingFiles) return;
    setState(() => _pickingFiles = true);
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'csv', 'xls', 'xlsx', 'jpg', 'jpeg', 'png'],
        allowMultiple: true,
        withData: false,
      );
      if (!mounted || result == null) return;
      setState(() {
        for (final file in result.files) {
          if (_documents.every((existing) => existing.name != file.name)) {
            _documents.add(file);
          }
        }
      });
    } on PlatformException {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('File picker unavailable. Please try again.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Unable to select that file.')),
        );
      }
    } finally {
      if (mounted) setState(() => _pickingFiles = false);
    }
  }

  void _next() {
    if (_step < 3) {
      if (!(_formKeys[_step].currentState?.validate() ?? false)) return;
      setState(() => _step++);
      return;
    }
    if (!_consent) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please confirm the information and consent first.')),
      );
      return;
    }
    final data = <String, dynamic>{
      'service': 'portfolio_diagnosis',
      'plan_id': widget.plan.id,
      'contact': {
        'full_name': _name.text.trim(),
        'email': _email.text.trim(),
        'mobile': _mobile.text.trim(),
        'age': int.tryParse(_age.text.trim()),
        'city': _city.text.trim(),
        'existing_student': _isStudent,
      },
      'portfolio': {
        'account_count': int.tryParse(_accounts.text.trim()),
        'approximate_value_inr': double.tryParse(_value.text.replaceAll(',', '')),
        'broker': _broker.text.trim(),
        'investor_experience': _experience,
        'relationship': _relationship,
        'objectives': _goals.text.trim(),
      },
      // Files are local selections only. They are not uploaded or persisted.
      'documents': _documents.map((f) => {'name': f.name, 'size': f.size}).toList(),
      'consent': true,
    };
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => NativePaymentHandoffPage(
          serviceName: 'Portfolio Diagnosis',
          planName: widget.plan.title,
          summary: {
            'Applicant': _name.text.trim(),
            'Email': _email.text.trim(),
            'Accounts': _accounts.text.trim(),
            'Selected documents': '${_documents.length}',
            'Final price': 'To be confirmed by backend',
          },
          draftData: data,
        ),
      ),
    );
  }

  Widget _personalStep() {
    return Form(
      key: _formKeys[0],
      child: NativeSectionCard(
        title: 'Contact information',
        icon: Icons.person_outline_rounded,
        child: Column(children: [
          NativeField(controller: _name, label: 'Full name', requiredField: true),
          NativeField(controller: _email, label: 'Email address',
              keyboardType: TextInputType.emailAddress,
              isEmail: true, requiredField: true),
          NativeField(controller: _mobile, label: 'Mobile number',
              keyboardType: TextInputType.phone,
              isPhone: true, requiredField: true),
          NativeField(controller: _age, label: 'Age',
              keyboardType: TextInputType.number,
              integerOnly: true, requiredField: true, isPositiveNumber: true),
          NativeField(controller: _city, label: 'City', requiredField: true),
          SwitchListTile.adaptive(
            contentPadding: EdgeInsets.zero,
            title: const Text('Existing Profit From It student',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
            subtitle: const Text('Discount eligibility will be verified by Laravel.',
                style: TextStyle(fontSize: 11.5)),
            value: _isStudent,
            activeColor: NativeFormTheme.teal,
            onChanged: (v) => setState(() => _isStudent = v),
          ),
        ]),
      ),
    );
  }

  Widget _investmentStep() {
    return Form(
      key: _formKeys[1],
      child: NativeSectionCard(
        title: 'Portfolio overview',
        icon: Icons.pie_chart_outline_rounded,
        child: Column(children: [
          NativeField(controller: _accounts, label: 'Number of accounts',
              requiredField: true, isPositiveNumber: true,
              keyboardType: TextInputType.number, integerOnly: true),
          NativeField(controller: _value, label: 'Approximate total value (₹)',
              keyboardType: TextInputType.number,
              isNonNegativeNumber: true),
          NativeField(controller: _broker, label: 'Broker / platform (optional)'),
          NativeSelect(
            label: 'Investment experience',
            value: _experience,
            options: const ['Beginner', '1–3 years', '3–5 years', '5+ years'],
            onChanged: (value) => setState(() => _experience = value),
          ),
          NativeSelect(
            label: 'Account ownership',
            value: _relationship,
            options: const ['Self', 'Spouse', 'Parents', 'Entire family', 'Other'],
            onChanged: (value) => setState(() => _relationship = value),
          ),
          NativeField(controller: _goals, label: 'Primary concern or objectives',
              hint: 'E.g. concentration, diversification, valuation', maxLines: 3),
          const NativeNotice(
            text: 'Your submitted account details will be reviewed only after '
                'the backend, secure upload, and payment verification are connected.',
          ),
        ]),
      ),
    );
  }

  Widget _documentsStep() {
    return Form(
      key: _formKeys[2],
      child: NativeSectionCard(
        title: 'Portfolio documents (optional)',
        icon: Icons.upload_file_rounded,
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('You may select holding statements or screenshots now. '
              'The app will not upload or save them until the backend integration is ready.',
              style: TextStyle(fontSize: 13, height: 1.5, color: NativeFormTheme.muted)),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: _pickingFiles ? null : _pickDocuments,
            icon: const Icon(Icons.attach_file_rounded),
            label: Text(_pickingFiles ? 'Opening files…' : 'Choose documents'),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 15),
              foregroundColor: NativeFormTheme.teal,
            ),
          ),
          const SizedBox(height: 12),
          ..._documents.asMap().entries.map((entry) => Card(
            margin: const EdgeInsets.only(bottom: 8),
            color: const Color(0xFFF8FAFD),
            child: ListTile(
              dense: true,
              leading: const Icon(Icons.description_outlined,
                  color: NativeFormTheme.blue),
              title: Text(entry.value.name,
                  maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text('${(entry.value.size / 1024).toStringAsFixed(0)} KB'),
              trailing: IconButton(
                icon: const Icon(Icons.close_rounded),
                onPressed: () => setState(() => _documents.removeAt(entry.key)),
              ),
            ),
          )),
          if (_documents.isEmpty) ...[
            const SizedBox(height: 10),
            const Center(child: Text('No documents selected',
                style: TextStyle(color: NativeFormTheme.muted, fontSize: 12))),
          ],
        ]),
      ),
    );
  }

  Widget _reviewStep() {
    return NativeSectionCard(
      title: 'Review your request',
      icon: Icons.fact_check_outlined,
      child: Column(children: [
        NativeReviewRow('Plan', widget.plan.title),
        NativeReviewRow('Full name', _name.text.trim()),
        NativeReviewRow('Email', _email.text.trim()),
        NativeReviewRow('Mobile', _mobile.text.trim()),
        NativeReviewRow('City', _city.text.trim()),
        NativeReviewRow('Number of accounts', _accounts.text.trim()),
        NativeReviewRow('Selected files', '${_documents.length}'),
        const Divider(height: 26),
        const NativeNotice(
          text: 'Pricing, taxes and applicable student discounts are indicative '
              'until confirmed by the Laravel backend. No payment is initiated here.',
        ),
        const SizedBox(height: 14),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          controlAffinity: ListTileControlAffinity.leading,
          value: _consent,
          activeColor: NativeFormTheme.teal,
          onChanged: (value) => setState(() => _consent = value ?? false),
          title: const Text('I confirm these details are accurate and consent to '
              'their use for my requested review once I submit the application.',
              style: TextStyle(fontSize: 12.5, height: 1.5)),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final titles = [
      'Tell us about yourself',
      'Help us understand your portfolio',
      'Supporting documents',
      'Almost done',
    ];
    final descriptions = [
      'Basic details so the advisory team can identify your request.',
      'These details help scope the ${widget.plan.title.toLowerCase()}.',
      'File selection is optional at this stage.',
      'Check your information before proceeding to the checkout preview.',
    ];
    final Widget content;
    switch (_step) {
      case 0:
        content = _personalStep();
        break;
      case 1:
        content = _investmentStep();
        break;
      case 2:
        content = _documentsStep();
        break;
      default:
        content = _reviewStep();
    }
    return Scaffold(
      backgroundColor: NativeFormTheme.bg,
      appBar: AppBar(
        title: Text(widget.plan.title, style: const TextStyle(fontSize: 17)),
        backgroundColor: Colors.white,
        foregroundColor: NativeFormTheme.navy,
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 740),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(18, 22, 18, 28),
              children: [
                NativeStepHeader(
                  labels: _steps,
                  step: _step,
                  title: titles[_step],
                  description: descriptions[_step],
                ),
                const SizedBox(height: 20),
                content,
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: NativeFlowFooter(
        onBack: _step > 0 ? () => setState(() => _step--) : null,
        onNext: _next,
        nextLabel: _step == 3 ? 'Review Payment Step' : 'Continue',
      ),
    );
  }
}
