import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:url_launcher/url_launcher.dart';

import 'portfolio_diagnosis_widgets.dart';

/// Website-backed onboarding for the Portfolio Diagnosis plans.
///
/// The server remains responsible for personal-detail validation, determining
/// student eligibility, calculating GST/discounts, creating payment orders,
/// verifying payment with its payment provider, and the portfolio upload.
/// No card details, payment secrets or checkout totals are handled in Flutter.
///
/// A hosted flow is intentional: no dedicated Portfolio Diagnosis API or
/// payment-verification contract was included in the supplied Laravel source.
class PortfolioDiagnosisCheckoutPage extends StatefulWidget {
  const PortfolioDiagnosisCheckoutPage({
    super.key,
    required this.plan,
  });

  final PortfolioDiagnosisPlan plan;

  @override
  State<PortfolioDiagnosisCheckoutPage> createState() =>
      _PortfolioDiagnosisCheckoutPageState();
}

enum PortfolioDiagnosisPlan {
  individual,
  family,
}

extension PortfolioDiagnosisPlanDisplay on PortfolioDiagnosisPlan {
  String get label => this == PortfolioDiagnosisPlan.individual
      ? 'Individual Audit'
      : 'Family Wealth Audit';

  /// These URLs are the two existing website CTA destinations.
  /// Individual Audit: /order-user-details
  /// Family Wealth Audit: /order-user-details?plan=family
  Uri get onboardingUrl => Uri.https(
        'profitfromit.co.in',
        '/order-user-details',
        this == PortfolioDiagnosisPlan.family ? {'plan': 'family'} : null,
      );
}

class _PortfolioDiagnosisCheckoutPageState
    extends State<PortfolioDiagnosisCheckoutPage> {
  InAppWebViewController? _webView;
  late Uri _currentUri;
  int _progress = 0;
  bool _loading = true;
  String? _error;
  bool _openingBrowser = false;

  @override
  void initState() {
    super.initState();
    _currentUri = widget.plan.onboardingUrl;
  }

  InAppWebViewSettings get _settings => InAppWebViewSettings(
        javaScriptEnabled: true,
        useHybridComposition: true,
        isInspectable: kDebugMode,
        javaScriptCanOpenWindowsAutomatically: true,
        supportMultipleWindows: true,
        useShouldOverrideUrlLoading: true,
        mediaPlaybackRequiresUserGesture: true,
        allowsInlineMediaPlayback: true,
        iframeAllowFullscreen: true,
      );

  bool _isMainFrame(WebResourceRequest request) =>
      request.isForMainFrame == true;

  void _notify(String message) {
    if (!mounted) return;
    ScaffoldMessenger.maybeOf(context)?.showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _openInBrowser() async {
    if (_openingBrowser) return;
    setState(() => _openingBrowser = true);
    try {
      // Uses Android Chrome Custom Tabs / iOS SFSafariViewController before
      // trying a normal browser. This supports gateways incompatible with an
      // embedded WebView, but may not preserve POST-only checkout state.
      var opened = await launchUrl(
        _currentUri,
        mode: LaunchMode.inAppBrowserView,
      );
      if (!opened) {
        opened = await launchUrl(
          _currentUri,
          mode: LaunchMode.externalApplication,
        );
      }
      if (!opened) _notify('Could not open a secure browser.');
    } catch (_) {
      _notify('Unable to open a secure browser on this device.');
    } finally {
      if (mounted) setState(() => _openingBrowser = false);
    }
  }

  Future<void> _reload() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _progress = 0;
      _error = null;
    });
    try {
      final controller = _webView;
      if (controller == null) return;
      await controller.reload();
    } catch (_) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'Unable to reload the checkout page.';
        });
      }
    }
  }

  Future<bool> _confirmExit() async {
    final choice = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Leave portfolio review?'),
        content: const Text(
          'If you have started a payment, do not leave until the website '
          'confirms the result. Payment status is verified by the server.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Stay here'),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Leave'),
          ),
        ],
      ),
    );
    return choice ?? false;
  }

  Future<bool> _handleSystemBack() async {
    final controller = _webView;
    try {
      if (controller != null && await controller.canGoBack()) {
        await controller.goBack();
        return false;
      }
    } catch (_) {
      // Use the safe exit confirmation if the WebView became unavailable.
    }
    return _confirmExit();
  }

  Future<void> _close() async {
    if (await _confirmExit() && mounted) {
      Navigator.of(context).pop();
    }
  }

  Future<NavigationActionPolicy> _interceptNavigation(
    NavigationAction action,
  ) async {
    final webUri = action.request.url;
    if (webUri == null) return NavigationActionPolicy.CANCEL;
    final uri = Uri.tryParse(webUri.toString());
    if (uri == null) return NavigationActionPolicy.CANCEL;

    switch (uri.scheme.toLowerCase()) {
      case 'https':
      case 'about':
      case 'data':
      case 'blob':
        return NavigationActionPolicy.ALLOW;
      case 'http':
        _notify('Insecure HTTP payment navigation was blocked.');
        return NavigationActionPolicy.CANCEL;
      default:
        // UPI/intent schemes must be handed to an installed payment app.
        try {
          final launched = await launchUrl(
            uri,
            mode: LaunchMode.externalApplication,
          );
          if (!launched) {
            _notify('No installed app could open this payment link.');
          }
        } catch (_) {
          _notify('This payment link could not be opened on your device.');
        }
        return NavigationActionPolicy.CANCEL;
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _handleSystemBack,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.white,
          foregroundColor: DiagnosisPalette.ink,
          elevation: 0,
          scrolledUnderElevation: 0,
          leading: IconButton(
            onPressed: _close,
            icon: const Icon(Icons.close_rounded),
            tooltip: 'Close review',
          ),
          titleSpacing: 0,
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Secure Portfolio Review',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 16,
                  )),
              Text(widget.plan.label,
                  style: const TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 11,
                    color: DiagnosisPalette.muted,
                  )),
            ],
          ),
          actions: [
            IconButton(
              onPressed: _reload,
              icon: const Icon(Icons.refresh_rounded),
              tooltip: 'Reload page',
            ),
            IconButton(
              onPressed: _openingBrowser ? null : _openInBrowser,
              icon: const Icon(Icons.open_in_browser_rounded),
              tooltip: 'Open in secure browser',
            ),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: [
              if (_loading && _error == null)
                LinearProgressIndicator(
                  minHeight: 3,
                  value: _progress > 0 && _progress < 100
                      ? _progress / 100
                      : null,
                  color: DiagnosisPalette.blue,
                ),
              Expanded(
                child: Stack(
                  children: [
                    InAppWebView(
                      initialUrlRequest: URLRequest(
                        url: WebUri(widget.plan.onboardingUrl.toString()),
                      ),
                      initialSettings: _settings,
                      onWebViewCreated: (controller) => _webView = controller,
                      onProgressChanged: (controller, progress) {
                        if (mounted && _error == null) {
                          setState(() => _progress = progress);
                        }
                      },
                      onLoadStart: (controller, url) {
                        if (!mounted) return;
                        final parsed = Uri.tryParse(url?.toString() ?? '');
                        setState(() {
                          if (parsed != null && parsed.scheme == 'https') {
                            _currentUri = parsed;
                          }
                          _error = null;
                          _loading = true;
                        });
                      },
                      onLoadStop: (controller, url) {
                        if (!mounted) return;
                        final parsed = Uri.tryParse(url?.toString() ?? '');
                        setState(() {
                          if (parsed != null && parsed.scheme == 'https') {
                            _currentUri = parsed;
                          }
                          _progress = 100;
                          _loading = false;
                        });
                        // Intentionally do not infer payment success from a URL.
                        // The hosted website verifies payment and displays the
                        // next portfolio-upload step to the customer.
                      },
                      shouldOverrideUrlLoading: (controller, action) =>
                          _interceptNavigation(action),
                      onCreateWindow: (controller, action) async {
                        if (!mounted) return false;
                        // Many gateways open an authorization/3-D Secure popup.
                        // A child WebView shares the original window opener.
                        Navigator.of(context).push<void>(
                          MaterialPageRoute<void>(
                            builder: (_) => _PortfolioPaymentWindow(
                              windowId: action.windowId,
                            ),
                          ),
                        );
                        return true;
                      },
                      onReceivedError: (controller, request, error) {
                        if (!mounted || !_isMainFrame(request)) return;
                        setState(() {
                          _loading = false;
                          _error = 'The secure review page could not load. '
                              'Please check your connection.';
                        });
                      },
                      onReceivedHttpError: (controller, request, response) {
                        if (!mounted || !_isMainFrame(request)) return;
                        final code = response.statusCode ?? 0;
                        if (code < 400) return;
                        setState(() {
                          _loading = false;
                          _error = 'The server returned HTTP $code.';
                        });
                      },
                    ),
                    if (_error != null)
                      Positioned.fill(
                        child: Container(
                          color: const Color(0xFFF5F7FB),
                          alignment: Alignment.center,
                          padding: const EdgeInsets.all(24),
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 420),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(
                                  Icons.wifi_off_rounded,
                                  size: 44,
                                  color: DiagnosisPalette.blue,
                                ),
                                const SizedBox(height: 14),
                                const Text(
                                  'Unable to load secure onboarding',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 19,
                                    fontWeight: FontWeight.w800,
                                    color: DiagnosisPalette.ink,
                                  ),
                                ),
                                const SizedBox(height: 9),
                                Text(_error!, textAlign: TextAlign.center),
                                const SizedBox(height: 18),
                                FilledButton.icon(
                                  onPressed: _reload,
                                  icon: const Icon(Icons.refresh_rounded),
                                  label: const Text('Try again'),
                                ),
                                const SizedBox(height: 8),
                                TextButton.icon(
                                  onPressed: _openInBrowser,
                                  icon: const Icon(Icons.open_in_browser_rounded),
                                  label: const Text('Use secure in-app browser'),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                color: const Color(0xFFF4F7FD),
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 9,
                ),
                child: const Row(
                  children: [
                    Icon(Icons.lock_outline_rounded,
                        size: 16, color: DiagnosisPalette.blue),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Payment, discounts and portfolio upload are handled '
                        'by the secure Profit From It website.',
                        style: TextStyle(
                          fontSize: 10.5,
                          color: DiagnosisPalette.muted,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// A separate, native route for third-party payment popup windows.
class _PortfolioPaymentWindow extends StatelessWidget {
  const _PortfolioPaymentWindow({required this.windowId});

  final int windowId;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text('Secure Payment'),
      ),
      body: SafeArea(
        child: InAppWebView(
          windowId: windowId,
          initialSettings: InAppWebViewSettings(
            javaScriptEnabled: true,
            useHybridComposition: true,
            useShouldOverrideUrlLoading: true,
          ),
          shouldOverrideUrlLoading: (controller, action) async {
            final url = action.request.url;
            final uri = Uri.tryParse(url?.toString() ?? '');
            if (uri == null) return NavigationActionPolicy.CANCEL;
            if (uri.scheme == 'http') return NavigationActionPolicy.CANCEL;
            if (uri.scheme == 'https' || uri.scheme == 'about' ||
                uri.scheme == 'data' || uri.scheme == 'blob') {
              return NavigationActionPolicy.ALLOW;
            }
            try {
              await launchUrl(uri, mode: LaunchMode.externalApplication);
            } catch (_) {
              // The user can return to the parent page and use browser fallback.
            }
            return NavigationActionPolicy.CANCEL;
          },
        ),
      ),
    );
  }
}
