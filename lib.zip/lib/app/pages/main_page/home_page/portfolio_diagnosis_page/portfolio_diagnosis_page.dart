import 'package:flutter/material.dart';
import 'package:webinar/app/widgets/native_service_forms/native_service_form_widgets.dart';
import 'package:webinar/app/pages/main_page/home_page/portfolio_diagnosis_page/portfolio_diagnosis_widgets.dart';
import 'package:webinar/app/pages/main_page/home_page/portfolio_diagnosis_page/portfolio_diagnosis_form_page.dart';

/// Portfolio Diagnosis plans with native Flutter registration and review.
class PortfolioDiagnosisPage extends StatelessWidget {
  const PortfolioDiagnosisPage({super.key});

  void _openForm(BuildContext context, DiagnosisPlan plan) {
    Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => PortfolioDiagnosisFormPage(plan: plan),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: DiagnosisPalette.background,
      appBar: AppBar(
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        foregroundColor: DiagnosisPalette.ink,
        title: const Text(
          'Portfolio Diagnosis',
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
        ),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1050),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(18, 22, 18, 36),
              children: [
                const DiagnosisIntroBanner(),
                const SizedBox(height: 27),
                const Text(
                  'Choose your review',
                  style: TextStyle(
                    color: DiagnosisPalette.ink,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 7),
                const Text(
                  'Two ways to assess portfolio health, risks and diversification.',
                  style: TextStyle(
                    color: DiagnosisPalette.muted,
                    fontSize: 13,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 17),
                LayoutBuilder(
                  builder: (context, constraints) {
                    final individual = DiagnosisPlanCard(
                      key: const ValueKey('individual_audit'),
                      badge: 'DIAGNOSTICS',
                      title: 'Individual Audit',
                      description:
                          'Single Demat review covering fundamental quality, industry diversification, and growth analysis.',
                      price: '₹2,000',
                      benefits: const [
                        'Single Demat Review',
                        '30m Expert Strategy Call',
                        'Portfolio Health Score',
                      ],
                      buttonText: 'Start Review Plan',
                      accent: DiagnosisPalette.blue,
                      softAccent: DiagnosisPalette.blueTint,
                      icon: Icons.manage_search_rounded,
                      onPressed: () =>
                          _openForm(context, DiagnosisPlan.individual),
                    );
                    final family = DiagnosisPlanCard(
                      key: const ValueKey('family_wealth_audit'),
                      badge: 'BEST VALUE FOR FAMILIES',
                      title: 'Family Wealth Audit',
                      description:
                          'Scientific Portfolio Health Score and Mutual Fund overlap audit for entire household portfolios.',
                      price: '₹6,000',
                      benefits: const [
                        'Up to 4 Accounts',
                        '60m Comprehensive Session',
                        'Mutual Fund Overlap Check',
                      ],
                      buttonText: 'Secure Family Portfolio',
                      accent: DiagnosisPalette.orange,
                      softAccent: DiagnosisPalette.orangeTint,
                      icon: Icons.family_restroom_rounded,
                      onPressed: () => _openForm(context, DiagnosisPlan.family),
                    );

                    if (constraints.maxWidth >= 660) {
                      return IntrinsicHeight(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Expanded(child: individual),
                            const SizedBox(width: 18),
                            Expanded(child: family),
                          ],
                        ),
                      );
                    }
                    return Column(
                      children: [
                        individual,
                        const SizedBox(height: 16),
                        family,
                      ],
                    );
                  },
                ),
                const SizedBox(height: 20),
                const NativeNotice(
                  text:
                      'Displayed fees are indicative. The final amount, taxes '
                      'and discounts will be confirmed after Laravel checkout '
                      'is connected. You can preview the native form now.',
                ),
                const SizedBox(height: 24),
                const DiagnosisDisclosure(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
