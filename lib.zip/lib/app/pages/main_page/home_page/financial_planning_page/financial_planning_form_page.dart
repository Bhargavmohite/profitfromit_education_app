import 'dart:math';

import 'package:flutter/material.dart';
import 'package:webinar/app/services/personal_services/personal_service_api.dart';
import 'package:webinar/app/pages/main_page/home_page/service_cart_page/service_cart_page.dart';
import 'package:webinar/app/widgets/native_service_forms/native_service_form_widgets.dart';

/// Native Financial Discovery wizard. UI and in-memory draft only.
/// Wire _draftPayload() to a Laravel repository when the API is ready.
class FinancialPlanningFormPage extends StatefulWidget {
  const FinancialPlanningFormPage({super.key});

  @override
  State<FinancialPlanningFormPage> createState() => _FinancialPlanningFormPageState();
}

class _FinancialPlanningFormPageState extends State<FinancialPlanningFormPage> {
  static const _steps = [
    'Personal', 'Cash flow', 'Assets & loans', 'Goals', 'Retirement & risk', 'Review',
  ];

  final _forms = List.generate(5, (_) => GlobalKey<FormState>());
  final Map<String, TextEditingController> _values = {
    'full_name': TextEditingController(),
    'email': TextEditingController(),
    'mobile': TextEditingController(),
    'age': TextEditingController(),
    'city': TextEditingController(),
    'dependents': TextEditingController(),
    'monthly_income': TextEditingController(),
    'spouse_monthly_income': TextEditingController(),
    'monthly_expenses': TextEditingController(),
    'monthly_sip': TextEditingController(),
    'monthly_emis': TextEditingController(),
    'cash_and_bank': TextEditingController(),
    'equity_and_mutual_funds': TextEditingController(),
    'property_value': TextEditingController(),
    'other_assets': TextEditingController(),
    'outstanding_loans': TextEditingController(),
    'goal_amount': TextEditingController(),
    'goal_years': TextEditingController(),
    'other_goals': TextEditingController(),
    'retirement_age': TextEditingController(),
    'retirement_monthly_expenses': TextEditingController(),
    'life_insurance': TextEditingController(),
    'health_insurance': TextEditingController(),
    'notes': TextEditingController(),
  };

  int _step = 0;
  String? _maritalStatus;
  String? _employment;
  String? _goalType;
  String? _riskTolerance;
  bool _isStudent = false;
  bool _consent = false;
  bool _saving = false;
  late final String _submissionId = 'fp_${DateTime.now().microsecondsSinceEpoch}_${Random.secure().nextInt(1 << 32)}';

  TextEditingController _controller(String key) => _values[key]!;
  String _text(String key) => _controller(key).text.trim();

  NativeField _field(String key, String label, {
    bool requiredField = false,
    bool email = false,
    bool phone = false,
    bool money = false,
    bool integer = false,
    int maxLines = 1,
    String? hint,
  }) {
    return NativeField(
      controller: _controller(key),
      label: label,
      hint: hint,
      requiredField: requiredField,
      isEmail: email,
      isPhone: phone,
      isNonNegativeNumber: money,
      isPositiveNumber: integer && requiredField,
      integerOnly: integer,
      maxLines: maxLines,
      keyboardType: email
          ? TextInputType.emailAddress
          : phone
              ? TextInputType.phone
              : (money || integer)
                  ? const TextInputType.numberWithOptions(decimal: true)
                  : TextInputType.text,
    );
  }

  @override
  void dispose() {
    for (final controller in _values.values) {
      controller.dispose();
    }
    super.dispose();
  }

  Map<String, dynamic> _draftPayload() {
    double? money(String key) => double.tryParse(_text(key).replaceAll(',', ''));
    int? count(String key) => int.tryParse(_text(key));
    return {
      'service': 'financial_planning',
      'plan_id': 'holistic_financial_planning',
      'personal': {
        'full_name': _text('full_name'),
        'email': _text('email'),
        'mobile': _text('mobile'),
        'age': count('age'),
        'city': _text('city'),
        'dependents': count('dependents'),
        'marital_status': _maritalStatus,
        'employment': _employment,
        'existing_student': _isStudent,
      },
      'cash_flow': {
        'monthly_income_inr': money('monthly_income'),
        'spouse_monthly_income_inr': money('spouse_monthly_income'),
        'monthly_expenses_inr': money('monthly_expenses'),
        'monthly_sip_inr': money('monthly_sip'),
        'monthly_emis_inr': money('monthly_emis'),
      },
      'balance_sheet': {
        'cash_and_bank_inr': money('cash_and_bank'),
        'equity_and_mutual_funds_inr': money('equity_and_mutual_funds'),
        'property_value_inr': money('property_value'),
        'other_assets_inr': money('other_assets'),
        'outstanding_loans_inr': money('outstanding_loans'),
      },
      'goals': {
        'primary_goal': _goalType,
        'target_amount_inr': money('goal_amount'),
        'years_to_goal': count('goal_years'),
        'other_goals': _text('other_goals'),
      },
      'retirement_and_risk': {
        'retirement_age': count('retirement_age'),
        'retirement_monthly_expenses_inr': money('retirement_monthly_expenses'),
        'life_cover_inr': money('life_insurance'),
        'health_cover_inr': money('health_insurance'),
        'risk_tolerance': _riskTolerance,
        'notes': _text('notes'),
      },
      'consent': true,
    };
  }

  Future<void> _continue() async {
    if (_saving) return;
    if (_step < 5) {
      if (!(_forms[_step].currentState?.validate() ?? false)) return;
      setState(() => _step++);
      return;
    }
    if (!_consent) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please confirm the details before continuing.')),
      );
      return;
    }
    setState(() => _saving = true);
    try {
      // Server saves to financial_planning and adds a priced service-cart item
      // atomically. Repeat taps reuse the same submission id.
      await PersonalServiceApi.saveFinancialPlanningAndAddToCart(
        _draftPayload(), _submissionId,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Financial Planning saved and added to cart.')),
      );
      Navigator.of(context).pushReplacement<void, void>(
        MaterialPageRoute<void>(builder: (_) => const ServiceCartPage()),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Unable to add Financial Planning to cart: $error'),
        duration: const Duration(seconds: 6),
      ));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Widget _personal() => Form(
    key: _forms[0],
    child: NativeSectionCard(
      title: 'Personal profile', icon: Icons.person_outline_rounded,
      child: Column(children: [
        _field('full_name', 'Full name', requiredField: true),
        _field('email', 'Email address', email: true, requiredField: true),
        _field('mobile', 'Mobile number', phone: true, requiredField: true),
        _field('age', 'Age', integer: true, requiredField: true),
        _field('city', 'City', requiredField: true),
        NativeSelect(
          label: 'Marital status', value: _maritalStatus,
          options: const ['Single', 'Married', 'Other', 'Prefer not to say'],
          onChanged: (s) => setState(() => _maritalStatus = s),
        ),
        NativeSelect(
          label: 'Employment status', value: _employment,
          options: const ['Salaried', 'Self-employed', 'Business owner', 'Retired', 'Other'],
          onChanged: (s) => setState(() => _employment = s),
        ),
        _field('dependents', 'Number of dependents', integer: true),
        SwitchListTile.adaptive(
          contentPadding: EdgeInsets.zero,
          title: const Text('Existing Profit From It student',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
          subtitle: const Text('Eligibility will be verified during checkout.',
              style: TextStyle(fontSize: 11.5)),
          value: _isStudent,
          activeColor: NativeFormTheme.teal,
          onChanged: (value) => setState(() => _isStudent = value),
        ),
      ]),
    ),
  );

  Widget _cashFlow() => Form(
    key: _forms[1],
    child: NativeSectionCard(
      title: 'Monthly cash flow (₹)', icon: Icons.account_balance_wallet_outlined,
      child: Column(children: [
        _field('monthly_income', 'Your monthly income', requiredField: true, money: true),
        _field('spouse_monthly_income', 'Spouse / other household monthly income', money: true),
        _field('monthly_expenses', 'Household monthly expenses', requiredField: true, money: true),
        _field('monthly_sip', 'Monthly SIPs and recurring investments', money: true),
        _field('monthly_emis', 'Monthly EMIs / loan repayments', money: true),
        const NativeNotice(
          text: 'Use approximate monthly figures in INR. Do not include bank account '
              'numbers, passwords or other credentials.',
        ),
      ]),
    ),
  );

  Widget _assetsAndLoans() => Form(
    key: _forms[2],
    child: NativeSectionCard(
      title: 'Assets and liabilities (₹)', icon: Icons.account_balance_outlined,
      child: Column(children: [
        _field('cash_and_bank', 'Cash and bank balances', money: true),
        _field('equity_and_mutual_funds', 'Stocks, mutual funds and other investments', money: true),
        _field('property_value', 'Approximate property value', money: true),
        _field('other_assets', 'Other assets', money: true),
        const Divider(height: 24),
        _field('outstanding_loans', 'Total outstanding loans', money: true),
        const NativeNotice(
          text: 'These are provisional estimates for the financial discovery form. '
              'The advisory team will review the data after secure submission.',
        ),
      ]),
    ),
  );

  Widget _goals() => Form(
    key: _forms[3],
    child: NativeSectionCard(
      title: 'Financial goals', icon: Icons.flag_outlined,
      child: Column(children: [
        NativeSelect(
          label: 'Primary financial goal', requiredField: true, value: _goalType,
          options: const [
            'Retirement', 'Child education', 'Home purchase', 'Wealth creation',
            'Financial independence', 'Emergency reserve', 'Other',
          ],
          onChanged: (value) => setState(() => _goalType = value),
        ),
        _field('goal_amount', 'Target amount (₹)', money: true, requiredField: true),
        _field('goal_years', 'Years until goal', integer: true, requiredField: true),
        _field('other_goals', 'Other goals and important milestones',
            maxLines: 4, hint: 'One goal per line (optional)'),
      ]),
    ),
  );

  Widget _retirementAndRisk() => Form(
    key: _forms[4],
    child: NativeSectionCard(
      title: 'Retirement, protection and risk', icon: Icons.shield_outlined,
      child: Column(children: [
        _field('retirement_age', 'Target retirement age', integer: true),
        _field('retirement_monthly_expenses', 'Expected monthly retirement spending (₹)', money: true),
        _field('life_insurance', 'Existing life insurance cover (₹)', money: true),
        _field('health_insurance', 'Existing health insurance cover (₹)', money: true),
        NativeSelect(
          label: 'Comfort with investment fluctuations', value: _riskTolerance,
          options: const [
            'Low – prioritise stability',
            'Moderate – balance stability and growth',
            'High – comfortable with significant volatility',
            'Not sure',
          ],
          onChanged: (value) => setState(() => _riskTolerance = value),
        ),
        _field('notes', 'Anything else your planner should know?', maxLines: 4),
      ]),
    ),
  );

  Widget _review() => NativeSectionCard(
    title: 'Financial discovery summary', icon: Icons.fact_check_outlined,
    child: Column(children: [
      const NativeReviewRow('Selected plan', 'Holistic Financial Planning'),
      NativeReviewRow('Full name', _text('full_name')),
      NativeReviewRow('Email', _text('email')),
      NativeReviewRow('Monthly income (₹)', _text('monthly_income')),
      NativeReviewRow('Monthly expenses (₹)', _text('monthly_expenses')),
      NativeReviewRow('Primary goal', _goalType ?? ''),
      NativeReviewRow('Target amount (₹)', _text('goal_amount')),
      NativeReviewRow('Years to goal', _text('goal_years')),
      NativeReviewRow('Risk tolerance', _riskTolerance ?? ''),
      const Divider(height: 25),
      const NativeNotice(
        text: 'When you tap Add to Cart, your financial discovery details will be '
            'submitted securely to the Laravel server. The service price and GST '
            'will be calculated by the backend before payment.',
      ),
      const SizedBox(height: 12),
      CheckboxListTile(
        contentPadding: EdgeInsets.zero,
        controlAffinity: ListTileControlAffinity.leading,
        value: _consent,
        activeColor: NativeFormTheme.teal,
        title: const Text('I confirm these details are accurate and consent '
            'to their use for financial planning once I submit the application.',
            style: TextStyle(fontSize: 12.5, height: 1.5)),
        onChanged: (v) => setState(() => _consent = v ?? false),
      ),
    ]),
  );

  @override
  Widget build(BuildContext context) {
    final titles = [
      'Tell us about yourself',
      'Your income and expenses',
      'What you own and owe',
      'What are you planning for?',
      'Your future and risk comfort',
      'Review your financial profile',
    ];
    final descriptions = [
      'Start with the household details relevant to your financial plan.',
      'Share approximate monthly numbers to map your cash flow.',
      'Build an initial picture of your current net worth.',
      'Set priorities and time horizons for your major goals.',
      'Help us understand retirement and protection needs.',
      'You can go back to edit any section before final checkout.',
    ];
    final Widget content;
    switch (_step) {
      case 0: content = _personal(); break;
      case 1: content = _cashFlow(); break;
      case 2: content = _assetsAndLoans(); break;
      case 3: content = _goals(); break;
      case 4: content = _retirementAndRisk(); break;
      default: content = _review();
    }

    return Scaffold(
      backgroundColor: NativeFormTheme.bg,
      appBar: AppBar(
        title: const Text('Financial Discovery', style: TextStyle(fontSize: 17)),
        backgroundColor: Colors.white,
        foregroundColor: NativeFormTheme.navy,
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 740),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(18, 22, 18, 28),
              children: [
                NativeStepHeader(
                  labels: _steps, step: _step,
                  title: titles[_step], description: descriptions[_step],
                ),
                const SizedBox(height: 20),
                content,
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: NativeFlowFooter(
        onBack: _step > 0 ? () => setState(() => _step--) : null,
        onNext: _continue,
        nextLabel: _saving ? 'Saving…' : (_step == 5 ? 'Save & Add to Cart' : 'Continue'),
        isBusy: _saving,
      ),
    );
  }
}
