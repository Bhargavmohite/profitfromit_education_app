import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webinar/app/pages/main_page/home_page/investment_baskets_page/investment_basket_data.dart';
import 'package:webinar/app/pages/main_page/home_page/investment_baskets_page/investment_basket_widgets.dart';

/// Opens the selected basket's official Maxfolio details in an in-app WebView.
/// WebView uses the existing `webview_flutter` dependency in this project.
class InvestmentBasketWebViewPage extends StatefulWidget {
  const InvestmentBasketWebViewPage({
    super.key,
    required this.basket,
  });

  final InvestmentBasket basket;

  @override
  State<InvestmentBasketWebViewPage> createState() =>
      _InvestmentBasketWebViewPageState();
}

class _InvestmentBasketWebViewPageState
    extends State<InvestmentBasketWebViewPage> {
  late final WebViewController _controller;
  bool _isLoading = true;
  int _progress = 0;
  String? _error;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) {
            if (!mounted) return;
            setState(() {
              _isLoading = true;
              _progress = 0;
              _error = null;
            });
          },
          onProgress: (progress) {
            if (!mounted) return;
            setState(() => _progress = progress);
          },
          onPageFinished: (_) {
            if (!mounted) return;
            setState(() {
              _isLoading = false;
              _progress = 100;
            });
          },
          onWebResourceError: (error) {
            // Do not cover a successfully loaded page due to an image,
            // font or other secondary resource failing.
            if (error.isForMainFrame == false || !mounted) return;
            setState(() {
              _isLoading = false;
              _error = 'Unable to load basket details. '
                  'Please check your internet connection and try again.';
            });
          },
        ),
      );
    _loadDetails();
  }

  Future<void> _loadDetails() async {
    setState(() {
      _isLoading = true;
      _progress = 0;
      _error = null;
    });
    try {
      await _controller.loadRequest(Uri.parse(widget.basket.detailsUrl));
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = 'Unable to open basket details. Please try again.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: BasketColors.ink,
        elevation: 0,
        scrolledUnderElevation: 0,
        titleSpacing: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              widget.basket.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: BasketColors.ink,
              ),
            ),
            const Text(
              'Full Basket Details',
              style: TextStyle(fontSize: 11, color: BasketColors.secondary),
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: _loadDetails,
            tooltip: 'Reload details',
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(child: WebViewWidget(controller: _controller)),
            if (_isLoading)
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: LinearProgressIndicator(
                  minHeight: 3,
                  value: _progress > 0 && _progress < 100
                      ? _progress / 100
                      : null,
                  color: BasketColors.blue,
                  backgroundColor: BasketColors.canvas,
                ),
              ),
            if (_error != null)
              Positioned.fill(
                child: ColoredBox(
                  color: Colors.white,
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(28),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.wifi_off_rounded,
                            size: 48,
                            color: BasketColors.secondary,
                          ),
                          const SizedBox(height: 14),
                          const Text(
                            'Could not load details',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: BasketColors.ink,
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            _error!,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: BasketColors.secondary,
                              fontSize: 13,
                            ),
                          ),
                          const SizedBox(height: 20),
                          FilledButton.icon(
                            onPressed: _loadDetails,
                            icon: const Icon(Icons.refresh_rounded),
                            label: const Text('Try Again'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
