import 'package:flutter/material.dart';
import 'package:webinar/common/utils/institutional_model_actions.dart';
import 'package:webinar/config/styles.dart';

import 'home_widget.dart';

/// One Institutional Models row. Rows can be placed at different positions
/// on the home page without duplicating the card UI or tap-handler logic.
class InstitutionalModelsSection extends StatelessWidget {
  const InstitutionalModelsSection.topRow({super.key}) : isTopRow = true;
  const InstitutionalModelsSection.bottomRow({super.key}) : isTopRow = false;

  final bool isTopRow;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (isTopRow)
          HomeWidget.titleAndMore('Institutional Models', isViewAll: false),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: isTopRow
                    ? _InstitutionalModelCard(
                        title: 'Portfolio Diagnosis',
                        subtitle: 'Health Check',
                        icon: Icons.trending_up_rounded,
                        onTap: () => openInstitutionalModel(
                          context,
                          InstitutionalModel.portfolioDiagnosis,
                        ),
                      )
                    : _InstitutionalModelCard(
                        title: 'Investment Baskets',
                        subtitle: '6 Curated Themes',
                        icon: Icons.shopping_basket_outlined,
                        onTap: () => openInstitutionalModel(
                          context,
                          InstitutionalModel.investmentBaskets,
                        ),
                      ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: isTopRow
                    ? _InstitutionalModelCard(
                        title: 'Financial Planning',
                        subtitle: 'Goal & Asset Map',
                        icon: Icons.account_balance_outlined,
                        onTap: () => openInstitutionalModel(
                          context,
                          InstitutionalModel.financialPlanning,
                        ),
                      )
                    : _InstitutionalModelCard(
                        title: 'Wealth Calculations',
                        subtitle: 'Time Machine & SIP',
                        icon: Icons.calculate_outlined,
                        onTap: () => openInstitutionalModel(
                          context,
                          InstitutionalModel.wealthCalculators,
                        ),
                      ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _InstitutionalModelCard extends StatelessWidget {
  const _InstitutionalModelCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    const cardRadius = BorderRadius.all(Radius.circular(14));

    return Semantics(
      button: true,
      label: title,
      child: Material(
        color: Colors.white,
        elevation: 1,
        shadowColor: const Color(0x160C2347),
        shape: RoundedRectangleBorder(
          borderRadius: cardRadius,
          side: const BorderSide(color: Color(0xFFE3E7EF)),
        ),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          borderRadius: cardRadius,
          child: SizedBox(
            height: 148,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 41,
                    height: 41,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: const Color(0xFFE5EEFF),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                      icon,
                      color: const Color(0xFF0057F8),
                      size: 24,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: style16Bold().copyWith(
                      color: const Color(0xFF06152E),
                      height: 1.15,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: style12Regular().copyWith(
                      color: const Color(0xFF7B8497),
                      height: 1.2,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
