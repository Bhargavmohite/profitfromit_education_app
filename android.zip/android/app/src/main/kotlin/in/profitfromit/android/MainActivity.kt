package `in`.profitfromit.android

import io.flutter.embedding.android.FlutterActivity
import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEventsLogger;


class MainActivity: FlutterActivity() {
}
